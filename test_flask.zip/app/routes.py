# app/routes.py

from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from app.models import SystemUser, Application, Scan, Credential, URL, Violation, Report
from app import db
from datetime import datetime
import re

# Initialize the blueprint
main = Blueprint('main', __name__)

# -------------------------------------------------------
# Home Route
# -------------------------------------------------------
@main.route('/')
def home():
    if "username" in session:
        return redirect(url_for('main.dashboard'))
    return render_template('index.html')


# -------------------------------------------------------
# Login Route
# -------------------------------------------------------
@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Fetch user from database
        user = SystemUser.query.filter_by(username=username).first()

        # Validate user credentials
        if user and check_password_hash(user.password_hash, password):
            session['username'] = username
            session['user_id'] = user.user_id
            return redirect(url_for('main.dashboard'))
        else:
            return render_template('login.html', error='Invalid credentials')

    return render_template('login.html')

# -------------------------------------------------------
# Login API (POST)
# -------------------------------------------------------
@main.route('/api/login', methods=['POST'])
def login_post():
    try:
        data = request.get_json()

        email = data.get('email')
        password = data.get('password')

        if not email or not password:
            return jsonify({'success': False, 'message': 'All fields are required.'}), 400

        # Check if user exists
        user = SystemUser.query.filter_by(email=email).first()
        if not user:
            return jsonify({'success': False, 'message': 'Invalid email or password.'}), 401

        # Verify password
        if not check_password_hash(user.password_hash, password):
            return jsonify({'success': False, 'message': 'Invalid email or password.'}), 401

        # Store session info
        session['user_id'] = user.user_id
        session['username'] = user.username
        session['role'] = user.role

        # Redirect user to dashboard (or homepage)
        return jsonify({
            'success': True,
            'message': f'Welcome back, {user.username}!',
            'redirect_url': url_for('main.dashboard')  # change if your dashboard route name differs
        }), 200

    except Exception as e:
        print("Login error:", e)
        return jsonify({'success': False, 'message': 'Internal Server Error'}), 500


# -------------------------------------------------------
# Signup Page
# -------------------------------------------------------
@main.route('/signup')
def signup():
    return render_template('signup.html')


# -------------------------------------------------------
# Signup API (POST)
# -------------------------------------------------------
@main.route('/api/signup', methods=['POST'])
def signup_post():
    try:
        data = request.get_json()

        username = data.get('username')
        email = data.get('email')
        password = data.get('password')

        # Check for missing fields
        if not username or not email or not password:
            return jsonify({'success': False, 'message': 'All fields are required.'}), 400

        # Check if user already exists
        existing_user = SystemUser.query.filter(
            (SystemUser.username == username) | (SystemUser.email == email)
        ).first()
        if existing_user:
            return jsonify({'success': False, 'message': 'Username or email already exists.'}), 400

        # Hash password
        hashed_password = generate_password_hash(password)

        # Create new user (default role as "user")
        new_user = SystemUser(
            username=username,
            email=email,
            password_hash=hashed_password,
            role="user",
            created_at=datetime.utcnow()
        )

        db.session.add(new_user)
        db.session.commit()

        # Send redirect URL for the frontend to use
        return jsonify({
            'success': True,
            'message': 'User created successfully!',
            'redirect_url': url_for('main.login')
        }), 201

    except Exception as e:
        print("Signup error:", e)
        return jsonify({'success': False, 'message': 'Internal Server Error'}), 500


# -------------------------------------------------------
# Email Check API
# -------------------------------------------------------
# @main.route('/api/check-email', methods=['POST'])
# def check_email():
#     try:
#         data = request.get_json()
#         email = data.get('email')

#         exists = User.query.filter_by(email=email).first() is not None

#         return jsonify({'exists': exists})

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500


# -------------------------------------------------------
# Dashboard Route
# -------------------------------------------------------
@main.route('/dashboard')
def dashboard():
    # ✅ Check if logged in
    if 'user_id' not in session:
        return redirect(url_for('main.login'))

    # ✅ Get user from session
    user_id = session['user_id']
    user = SystemUser.query.get(user_id)

    if not user:
        # In case session exists but user is deleted
        session.clear()
        return redirect(url_for('main.login'))

    # ✅ Fetch recent scans
    scans = (
        Scan.query.filter_by(user_id=user.user_id)
        .order_by(Scan.created_at.desc())
        .limit(5)
        .all()
    )

    # ✅ Count all scans and total vulnerabilities
    total_scans = Scan.query.filter_by(user_id=user.user_id).count()
    total_vulns = sum(getattr(scan, 'vulnerable_count', 0) or 0 for scan in scans)

    # ✅ Render dashboard
    return render_template(
        'dashboard.html',
        username=user.username,
        scans=scans,
        total_scans=total_scans,
        total_vulns=total_vulns
    )

# -------------------------------------------------------
# Scan Page Route
# -------------------------------------------------------
@main.route('/scan')
def scan():
    # Check if logged in
    if 'user_id' not in session:
        return redirect(url_for('main.login'))
    
    user_id = session['user_id']
    user = SystemUser.query.get(user_id)
    
    if not user:
        session.clear()
        return redirect(url_for('main.login'))
    
    # Get user's applications for dropdown (optional)
    applications = Application.query.filter_by(user_id=user_id).all()
    
    return render_template('scan.html', username=user.username, applications=applications)


# -------------------------------------------------------
# Start Scan API (POST)
# -------------------------------------------------------
@main.route('/api/scans/start', methods=['POST'])
def start_scan():
    try:
        # Check if user is logged in
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': 'User not authenticated'
            }), 401
        
        user_id = session['user_id']
        data = request.get_json()
        
        # Extract form data
        app_name = data.get('app_name')
        base_url = data.get('baseURL')
        max_depth = data.get('maxDepth', 3)
        roles = data.get('roles', [])
        options = data.get('options', {})
        
        # Validation
        if not app_name or not base_url:
            return jsonify({
                'success': False,
                'message': 'Application name and base URL are required'
            }), 400
        
        if not roles or len(roles) == 0:
            return jsonify({
                'success': False,
                'message': 'At least one role is required'
            }), 400
        
        # Check if application exists, create if not
        application = Application.query.filter_by(
            base_url=base_url, 
            user_id=user_id
        ).first()
        
        if not application:
            application = Application(
                user_id=user_id,
                name=app_name,
                base_url=base_url,
                description=data.get('description', ''),
                created_at=datetime.utcnow()
            )
            db.session.add(application)
            db.session.commit()
        
        # Create scan record
        new_scan = Scan(
            app_id=application.app_id,
            user_id=user_id,
            baseURL=base_url,
            maxDepth=max_depth,
            start_time=datetime.utcnow(),
            status='pending',
            vulnerable_count=0,
            created_at=datetime.utcnow()
        )
        
        db.session.add(new_scan)
        db.session.commit()
        
        # Store credentials if authentication is required
        if data.get('requires_auth', False):
            for role in roles:
                # You can customize this based on how you want to store credentials
                credential = Credential(
                    app_id=application.app_id,
                    role_name=role,
                    email=data.get('username', ''),
                    password=data.get('password', ''),
                    created_at=datetime.utcnow()
                )
                db.session.add(credential)
        
        db.session.commit()
        
        # TODO: Trigger the actual Playwright scan here
        # This would typically be done via a task queue like Celery
        # For now, we'll just update the status
        # trigger_playwright_scan(new_scan.scan_id, base_url, max_depth, roles, options)
        
        # Update scan status to running (simulated)
        new_scan.status = 'running'
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Scan started successfully',
            'scan_id': new_scan.scan_id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Error starting scan: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'An error occurred while starting the scan'
        }), 500


# -------------------------------------------------------
# Get Scan Status API
# -------------------------------------------------------
@main.route('/api/scans/<int:scan_id>/status', methods=['GET'])
def get_scan_status(scan_id):
    try:
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': 'User not authenticated'
            }), 401
        
        user_id = session['user_id']
        
        scan = Scan.query.filter_by(
            scan_id=scan_id, 
            user_id=user_id
        ).first()
        
        if not scan:
            return jsonify({
                'success': False,
                'message': 'Scan not found'
            }), 404
        
        return jsonify({
            'success': True,
            'scan': {
                'scan_id': scan.scan_id,
                'status': scan.status,
                'vulnerable_count': scan.vulnerable_count,
                'start_time': scan.start_time.isoformat() if scan.start_time else None,
                'end_time': scan.end_time.isoformat() if scan.end_time else None,
                'baseURL': scan.baseURL
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# -------------------------------------------------------
# Get User's Scans API
# -------------------------------------------------------
@main.route('/api/scans', methods=['GET'])
def get_user_scans():
    try:
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': 'User not authenticated'
            }), 401
        
        user_id = session['user_id']
        
        scans = Scan.query.filter_by(user_id=user_id)\
            .order_by(Scan.created_at.desc())\
            .limit(50)\
            .all()
        
        scan_list = []
        for scan in scans:
            scan_list.append({
                'scan_id': scan.scan_id,
                'baseURL': scan.baseURL,
                'status': scan.status,
                'vulnerable_count': scan.vulnerable_count or 0,
                'start_time': scan.start_time.isoformat() if scan.start_time else None,
                'end_time': scan.end_time.isoformat() if scan.end_time else None,
                'app_name': scan.application.name if scan.application else 'Unknown'
            })
        
        return jsonify({
            'success': True,
            'scans': scan_list
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# -------------------------------------------------------
# Delete Scan API
# -------------------------------------------------------
@main.route('/api/scans/<int:scan_id>', methods=['DELETE'])
def delete_scan(scan_id):
    try:
        if 'user_id' not in session:
            return jsonify({
                'success': False,
                'message': 'User not authenticated'
            }), 401
        
        user_id = session['user_id']
        
        scan = Scan.query.filter_by(
            scan_id=scan_id,
            user_id=user_id
        ).first()
        
        if not scan:
            return jsonify({
                'success': False,
                'message': 'Scan not found'
            }), 404
        
        db.session.delete(scan)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Scan deleted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

# -------------------------------------------------------
# Batch Scan Page Route
# -------------------------------------------------------

@main.route('/batch-scan')
def batch_scan():
    if "username" not in session:
        return redirect(url_for('main.login'))

    username = session['username']
    user = SystemUser.query.filter_by(username=username).first()
    if not user:
        return redirect(url_for('main.login'))

    # Fetch all applications owned by this user (for dropdown if needed)
    apps = Application.query.filter_by(user_id=user.user_id).all()

    return render_template('batch-scan.html', username=username, apps=apps)


# API to start batch scan
@main.route('/api/batch-scans/start', methods=['POST'])
def start_batch_scan():
    try:
        if "username" not in session:
            return jsonify({'success': False, 'message': 'Unauthorized access'}), 401

        data = request.get_json()
        username = session['username']
        user = SystemUser.query.filter_by(username=username).first()

        if not user:
            return jsonify({'success': False, 'message': 'User not found'}), 404

        urls = data.get('urls', [])
        settings = data.get('settings', {})
        roles = data.get('roles', [])
        options = data.get('options', {})
        execution = data.get('execution', {})

        if not urls:
            return jsonify({'success': False, 'message': 'No URLs provided.'}), 400

        scan_count = 0
        for item in urls:
            base_url = item.get('url')
            app_name = item.get('app_name')

            # Check if app exists or create new one
            app = Application.query.filter_by(name=app_name, user_id=user.user_id).first()
            if not app:
                app = Application(
                    user_id=user.user_id,
                    name=app_name,
                    base_url=base_url,
                    description="Imported via batch scan",
                    created_at=datetime.utcnow()
                )
                db.session.add(app)
                db.session.commit()

            # Create Scan entry
            new_scan = Scan(
                app_id=app.app_id,
                user_id=user.user_id,
                baseURL=base_url,
                maxDepth=settings.get('maxDepth', 3),
                start_time=datetime.utcnow(),
                status='Queued',
                vulnerable_count=0
            )
            db.session.add(new_scan)
            scan_count += 1

        db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Batch scan started successfully.',
            'scan_count': scan_count
        }), 201

    except Exception as e:
        print("Batch Scan Error:", e)
        db.session.rollback()
        return jsonify({'success': False, 'message': 'Internal Server Error'}), 500

# -------------------------------------------------------
# Logout Route
# -------------------------------------------------------
@main.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.login'))
